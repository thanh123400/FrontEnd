import './App2.css';
function App2() {
  return (
    <div>hahahahhaha</div>
  );
}

export default App2;
